NoOfQuestions=5;
Questions = Array(NoOfQuestions);
Answers= new Array(NoOfQuestions);
Choosed= false;

for(var i=0;i <NoOfQuestions;i++){
Answers[i]= new Array(4);
}
CorrectAnswer= new Array(NoOfQuestions);
QuestionNo=0;
Marks=0;
OptionChoosed=0;
Answer=5;
function AnswerChoosed(Ans)
{
Answer=Ans;
Choosed=true;
}
function load()
{
LoadQuestion();
}
function LoadQuestion(){
document.getElementById("Question").innerHTML= "(" + (QuestionNo + 1)+"):" + Questions[QuestionNo];
document.getElementById("Option0").innerHTML="(a)"+ Answers[QuestionNo][0];
document.getElementById("Option1").innerHTML="(b)"+ Answers[QuestionNo][1];
document.getElementById("Option2").innerHTML="(c)"+ Answers[QuestionNo][2];
document.getElementById("Option3").innerHTML="(d)"+ Answers[QuestionNo][3];
document.getElementById("Opt1").checked=false;
document.getElementById("Opt2").checked=false;
document.getElementById("Opt3").checked=false;
document.getElementById("Opt4").checked=false;
Answer=5;
}
function NextQuestion(){
if(Answer==CorrectAnswer[QuestionNo])
{
Marks++;
}
if(Choosed)
{
if(QuestionNo < NoOfQuestions - 1)
{
QuestionNo++;
LoadQuestion();
}
else
{
alert("End of Examination ...Marks are:'"+Marks+"'");
}
Choosed=false;
}
else
{
alert("No option choosed yet...");
}
}
Questions[0]="National Income estimates in India are prepared by";
Answers[0][0]="Planning Commission";
Answers[0][1]="Reserve Bank of India";
Answers[0][2]=" Central statistical organisation";
Answers[0][3]="Indian statistical Institute";
CorrectAnswer[0]=1;


Questions[1]="Ctrl, Shift and Alt are called .......... keys";
Answers[1][0]="modifier";
Answers[1][1]="function";
Answers[1][2]="alphanumeric";
Answers[1][3]="adjustment";
CorrectAnswer[1]=1;

Questions[2]="A computer cannot boot if it does not have the";
Answers[2][0]="Compiler";
Answers[2][1]="Loader";
Answers[2][2]=" Operating system ";
Answers[2][3]="Assembler";
CorrectAnswer[2]=3;

Questions[3]="Microsoft Office is an example of a";
Answers[3][0]="Closed source software";
Answers[3][1]="Open source software";
Answers[3][2]="Horizontal market software";
Answers[3][3]=" vertical market software";
CorrectAnswer[3]=3;

Questions[4]="The first computer was programmed using";
Answers[4][0]=" Assembly language";
Answers[4][1]="Machine language";
Answers[4][2]="Spaghetti code";
Answers[4][3]="Source code";
CorrectAnswer[4]=2;



